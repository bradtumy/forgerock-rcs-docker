Copyright 2019 ForgeRock AS. All Rights Reserved

Use of this code requires a commercial software license with ForgeRock AS.
or with one of its affiliates. All use shall be exclusively subject
to such license between the licensee and ForgeRock AS.
---------------------------------------------------------------------------

This folder contains a sample private/public key pair for the ICF Java Connector Server.
It is stored in the keyStore.pkcs12 file. 

The self-signed certificate containing the public key is wrapped into the jcs.cert file.
Import that certificate into your IDM security trustore
